﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace HttpGetSvc
{
    public partial class MainService : ServiceBase
    {
        public MainService()
        {
            InitializeComponent();
        }



        private string GetByCommon(string url)
        {
            return Benlai.Common.HttpClientUtils.Get(url);
        }

        private string GetByWebClient(string url)
        {
            using (var client = new WebClient())
            {
                client.Encoding = Encoding.UTF8;
                client.Proxy = null;

                return client.DownloadString(url);
            }
        }

        private string GetByHttpClient(string url)
        {
            var handler = new HttpClientHandler()
            {
                UseProxy = false,
            };

            using (var client = new HttpClient(handler))
            {
                return client.GetStringAsync(url).Result;
            }
        }

        private string GetByHttpWebRequest(string url)
        {
            var httpRequest = WebRequest.Create(url) as HttpWebRequest;

            httpRequest.Proxy = null;

            var response = httpRequest.GetResponse() as HttpWebResponse;

            using (var stream = response.GetResponseStream())
            using (var streamReader = new System.IO.StreamReader(stream, Encoding.UTF8))
            {
                return streamReader.ReadToEnd();
            }
        }

        protected override void OnStart(string[] args)
        {
            var mode = ConfigurationManager.AppSettings["Mode"].ToLower();

            var sw = new System.Diagnostics.Stopwatch();

            sw.Start();

            var url = "http://192.168.60.210:10083/";

            switch (mode)
            {
                case "common":
                    GetByCommon(url);
                    break;
                case "webclient":
                    GetByWebClient(url);
                    break;
                case "httprequest":
                    GetByHttpWebRequest(url);
                    break;
                case "httpclient":
                    GetByHttpClient(url);
                    break;
                default:
                    //do nothing
                    break;
            }

            sw.Stop();

            var logFile = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log.txt");

            using (var writer = new System.IO.StreamWriter(logFile))
            {
                writer.WriteLine(DateTime.Now.ToString() + "\t\t " + sw.ElapsedMilliseconds.ToString() + "ms");
            }
        }

        protected override void OnStop()
        {
        }
    }
}

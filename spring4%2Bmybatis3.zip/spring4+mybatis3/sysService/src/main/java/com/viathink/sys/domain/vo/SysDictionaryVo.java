package com.viathink.sys.domain.vo;

import com.viathink.sys.domain.SysDictionary;

/**
 * 
 * @author LiuJunGuang
 * @date 2014年3月3日下午1:32:09
 */
public class SysDictionaryVo extends SysDictionary {
	/**
	 * @fields serialVersionUID 
	 */
	private static final long serialVersionUID = -1742693268284282756L;

}
